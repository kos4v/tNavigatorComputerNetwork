import xtgeo

from ecl.summary import EclSum


def convert_gis():
    grid_parser = xtgeo.grid_from_file('grids/DynamicModel.grdecl', fformat="grdecl")
    for prop_name in ['GK', 'NGK', 'PERM', 'PORO', 'SATURATION', 'COLL', 'CS']:
        grid_parser.append_prop(xtgeo.gridproperty_from_file(
            f'grids/{prop_name}.grdecl', name=prop_name, grid=grid_parser,
        ))

    grid_df = grid_parser.get_dataframe()
    grid_df.to_csv('gis.csv', sep=';')


def read_tNav_result():
    result_dir = f'C:/Users/KosachevIV/Desktop/tNavTests/modelLaunch/RESULTS/DynamicModel'
    smsspec = f'{result_dir}/result.SMSPEC'
    unsmry = f'{result_dir}/result.UNSMRY'

    df = EclSum.load(smsspec, unsmry).pandas_frame()
    for name in df.keys():
        print(name)


if __name__ == '__main__':
    convert_gis()
